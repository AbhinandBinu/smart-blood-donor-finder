
import json
from donor import Donor

class DonorDatabase:
    def __init__(self, filename="donors.json"):
        self.filename = filename
        self.load()

    def load(self):
        try:
            with open(self.filename) as f:
                self.donors = [Donor.from_dict(d) for d in json.load(f)]
        except FileNotFoundError:
            self.donors = []

    def save(self):
        with open(self.filename, "w") as f:
            json.dump([d.to_dict() for d in self.donors], f, indent=4)

    def add(self, donor):
        self.donors.append(donor)
        self.save()

    def approved(self):
        return [d for d in self.donors if d.status == "approved"]

    def pending(self):
        return [d for d in self.donors if d.status == "pending"]
