
from flask import Flask, render_template, request, redirect, url_for
from donor import Donor
from database import DonorDatabase
from finder import DonorFinder
import os

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads"
db = DonorDatabase()

@app.route("/")
def index():
    return render_template("index.html", count=len(db.approved()))

@app.route("/add", methods=["GET","POST"])
def add():
    if request.method == "POST":
        file = request.files["certificate"]
        path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(path)

        donor = Donor(
            request.form["name"],
            request.form["blood_group"],
            request.form["location"],
            request.form["phone"],
            path
        )
        db.add(donor)
        return redirect(url_for("index"))
    return render_template("add.html")

@app.route("/search", methods=["GET","POST"])
def search():
    results = []
    if request.method == "POST":
        finder = DonorFinder(db.approved())
        results = finder.search(request.form["blood_group"])
    return render_template("search.html", results=results)

@app.route("/admin", methods=["GET","POST"])
def admin():
    if request.method == "POST":
        name = request.form["name"]
        for d in db.donors:
            if d.name == name:
                d.status = "approved"
        db.save()
    return render_template("admin.html", donors=db.pending())

if __name__ == "__main__":
    app.run(debug=True)
