
class DonorFinder:
    def __init__(self, donors):
        self.donors = donors

    def search(self, blood_group):
        return [d for d in self.donors if d.blood_group == blood_group.upper()]
