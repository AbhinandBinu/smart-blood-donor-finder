Admin Verified Smart Blood Donor Finder
Run: python app.py
